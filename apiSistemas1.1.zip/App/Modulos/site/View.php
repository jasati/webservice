<?php 
	include  ROOT.DS.'App'.DS.'Templates'.DS.'Site'.DS.'index.php';
 ?>
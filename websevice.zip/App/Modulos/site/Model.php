<?php 

use Jasati\Core\Master_Model;

/**
* Index model
*/
class Site_Model extends Master_Model
{

}

